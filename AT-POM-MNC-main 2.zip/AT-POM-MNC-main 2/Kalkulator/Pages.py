from Kalkulator.TestData import TestData
from Kalkulator.Locators import Locators
from BasePage import BasePage

class Hitung(BasePage):
    def __init__(self, driver):
        super().__init__(driver)
        self.driver.get(TestData.BASE_URL)

    def data_1(self):
        self.enter_text(Locators.INPUT_ANGKA, TestData.Data_1)
        self.click(Locators.HITUNG_BUTTON)
    def data_2(self):
        self.enter_text(Locators.INPUT_ANGKA, TestData.Data_2)
        self.click(Locators.HITUNG_BUTTON)
    def data_3(self):
        self.enter_text(Locators.INPUT_ANGKA, TestData.Data_3)
        self.click(Locators.HITUNG_BUTTON)
    def data_4(self):
        self.enter_text(Locators.INPUT_ANGKA,TestData.Data_4)
        self.click(Locators.HITUNG_BUTTON)
    def data_5(self):
        self.enter_text(Locators.INPUT_ANGKA, TestData.Data_5)
        self.click(Locators.HITUNG_BUTTON)
    def data_6(self):
        self.enter_text(Locators.INPUT_ANGKA, TestData.Data_6)
        self.click(Locators.HITUNG_BUTTON)
    def data_7(self):
        self.enter_text(Locators.INPUT_ANGKA, TestData.Data_7)
        self.click(Locators.HITUNG_BUTTON)
    def data_8(self):
        self.enter_text(Locators.INPUT_ANGKA, TestData.Data_8)
        self.click(Locators.HITUNG_BUTTON)
    def data_9(self):
        self.enter_text(Locators.INPUT_ANGKA, TestData.Data_9)
        self.click(Locators.HITUNG_BUTTON)