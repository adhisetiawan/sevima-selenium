class TestData:
    # Open The URL
    BASE_URL = "https://qa.putraprima.id/#"

    # Data experiment input
    Data_1 = "1"
    Data_2 = "10"
    Data_3 = "50"
    Data_4 = "100"
    Data_5 = "150"
    Data_6 = "171"
    Data_7 = "-6"
    Data_8 = "abcdef"
    Data_9 = "5.7"

    #Result
    ALERT_ERROR = "Please enter an integer"
    RESULT_DATA_1 = "Faktorial dari 1 adalah: 1"
    RESULT_DATA_2 = "Faktorial dari 10 adalah: 3628800"
    RESULT_DATA_3 = "Faktorial dari 50 adalah: 3.0414093201713376e+64"
    RESULT_DATA_4 = "Faktorial dari 100 adalah: 9.332621544394418e+157"
    RESULT_DATA_5 = "Faktorial dari 150 adalah: 5.7133839564458575e+262"
    RESULT_DATA_6 = "Please enter an integer"
    RESULT_DATA_7 = "Please enter an integer"
    RESULT_DATA_8 = "Please enter an integer"
    RESULT_DATA_9 = "Please enter an integer"

