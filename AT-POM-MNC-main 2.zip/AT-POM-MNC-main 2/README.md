# Automation Mister Aladin

## Prerequisites
* [Download Chrome Webdriver](https://chromedriver.chromium.org/)
* [Install IDE PyCharm](https://www.jetbrains.com/pycharm/download/#section=linux)
* [Selenium Docs](https://selenium-python.readthedocs.io/)
* [Install Python](https://www.python.org/downloads/)
* [Pytest Docs](https://docs.pytest.org/en/6.2.x/contents.html)
* [Install Pip](https://pypi.org/project/pip/)

## Install Package Pycharm IDE
* Faker
* pytest
* selenium
* pytest-html

## Run The Test terminal
* Run All Test : pytest 
* Run Report : pytest -v --html=report.html
* Run Specific TestCase by function : pytest -k test_valid login
## Feature
Here is the core menu structure which user merchant.

```
Access User Merchant/
|- Dashboard 
    |- Profile
|- Merchant
|- Product
|- Order Summary

```
Here is the core menu structure which Admin Internal
```
Access Admin Internal/
|- Dashboard 
    |- Profile
|- Merchant
|- Product
|- Order Summary
|- User Setup
    |-Role Setup
    |- Merchant User Setup
```

her is link for acces Mister Aladin B2B
### User Merchant 
```
https://staging-partner-explore.misterb2b.com/login 
```

### Admin Internal 
```
https://staging-partner-explore.misterb2b.com/?appId=121001&appSecret=d300a6359bff9592982a6ac996dab4ec&token=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJlbWFpbCI6Imloc2FuQHJlZmFjdG9yeS5pZCIsImV4cCI6MTY2MDkwOTUyNiwiaWF0IjoxNjI5MzczNTI2LCJpc3MiOiJtaXN0ZXJhbGFkaW4uY29tIiwibmFtZSI6Ikloc2FuIFJlZmFjdG9yeSIsIm5iZiI6MTYyOTM3MzUyNiwicm9sZSI6ImFkbWluaXN0cmF0b3IiLCJzdWIiOjYzfQ.UWTrIjmx8gWT5q3SGqXAf_kKHevdelj3XKr_cbM8P80
```


